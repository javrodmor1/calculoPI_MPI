package ejemplos.ejemplo1.manual;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.IntStream;

import _datos.DatosMulticonjunto;
import _datos.DatosSubconjuntos;
import ejemplos.ejemplo1.MulticonjuntoEdge;
import ejemplos.ejemplo1.MulticonjuntoVertex;
import ejemplos.ejemplo2.SubconjuntosVertex;
import us.lsi.common.List2;
import us.lsi.graphs.virtual.VirtualVertex;

public record MulticonjuntoProblem(Integer index, Integer remaining){

	public static MulticonjuntoProblem of(Integer i, Integer rest) {
		return new MulticonjuntoProblem(i, rest);
	}
	
	// TODO Consulte las clases GraphsPI5 y TestPI5 
	
	public static MulticonjuntoProblem initial() {
		return of(0, DatosMulticonjunto.getSuma());
	}

	
	public List<Integer> actions() {
		List<Integer> alternativas = List2.empty();
		if(index < DatosMulticonjunto.getNumElementos()) {
			Integer value = DatosMulticonjunto.getElemento(index);
			Integer options = remaining / value;
			//alternativas = List2.rangeList(0, options + 1);
			//lo de arriba hace -->return IntStream.range(a,b).boxed().collect(Collectors.toList());
			//se podria dejar asi con el return alternativas
			if(index == DatosMulticonjunto.getNumElementos()-1) {
				if(remaining % value == 0) {
					alternativas.add(remaining / value);
				}else {
					alternativas.add(0);
				}
			}else {
				alternativas = List2.rangeList(0, options + 1);
			}
		}
		return alternativas;
	}
	
	
	public MulticonjuntoProblem neighbor(Integer a) {
		return of(index + 1, remaining - a * DatosMulticonjunto.getElemento(index));
	}
	
	public Double heuristic(SubconjuntosVertex v1, Predicate<SubconjuntosVertex> goal, SubconjuntosVertex v2) {
		return v1.remaining().isEmpty()? 0.: 
			IntStream.range(v1.index(), DatosSubconjuntos.getNumSubconjuntos())
			.filter(i -> !List2.intersection(v1.remaining(), 
					DatosSubconjuntos.getElementos(i)).isEmpty())
			.mapToDouble(i -> DatosSubconjuntos.getPeso(i)).min().orElse(100.);
	}	

	
	

}
