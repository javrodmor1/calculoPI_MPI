package ejemplos.tests;

import java.util.List;

//Clase para todos los tests del ejemplo 3 mediante Greedy, A*, PDR y BT 
public class TestsEjemplo3 {


	public static void main(String[] args) {
		List.of(1,2,3).forEach(num_test -> {
			// TODO Consulte los tests de los ejemplos 1 y 2 
		});
	}


}
