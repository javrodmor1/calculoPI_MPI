package ejemplos.ejemplo2;


import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

import _datos.DatosSubconjuntos;
import us.lsi.common.List2;
import us.lsi.common.Set2;
import us.lsi.graphs.virtual.VirtualVertex;

public record SubconjuntosVertex(Integer index, Set<Integer> remaining) 
    implements VirtualVertex<SubconjuntosVertex, SubconjuntosEdge, Integer>{
	
	
	public static SubconjuntosVertex of(Integer i, Set<Integer> rest) {
		return new SubconjuntosVertex(i, rest);
	}
	
	
	public static SubconjuntosVertex initial() {
		return of(0, Set2.copy(DatosSubconjuntos.getUniverso()));
	}
	
	
	public static Predicate<SubconjuntosVertex> goal(){
		return v->v.index() == DatosSubconjuntos.getNumSubconjuntos();
	}
	
	
	public static Predicate<SubconjuntosVertex> goalHasSolution(){
		return v->v.remaining.isEmpty();
	}
	
	// TODO Consulte las clases GraphsPI5 y TestPI5 
	@Override
	public List<Integer> actions() {
		List<Integer> alternativas = List2.empty();
		if(index < DatosSubconjuntos.getNumSubconjuntos()) {
			if(remaining.isEmpty()) {
				alternativas.add(0);
			}else {
				Set<Integer> rest = Set2.difference(remaining, DatosSubconjuntos.getElementos(index));
				if(index == DatosSubconjuntos.getNumSubconjuntos() - 1) { //Si estamos en el último subconjunto
					alternativas = rest.isEmpty()? List2.of(1): List2.empty();
				}else if(rest.equals(remaining)) { // Si el subconjunto no puede cubrir algun elemento de remaining	
					alternativas.add(0);
				}else { // En otro caso
					alternativas = List2.of(0,1);
				}
			}
		}
		return alternativas;
	}
	
	@Override
	public SubconjuntosVertex neighbor(Integer a) {
		Set<Integer> rest = a == 0 ? Set2.copy(remaining): Set2.difference(remaining, DatosSubconjuntos.getElementos(index));
		//CUIDADO: Deben ser objeto nuevos independientes del vértice original
		return of(index + 1, rest);
	}
	
	@Override
	public SubconjuntosEdge edge(Integer a) {
		return SubconjuntosEdge.of(this, neighbor(a), a);
	}
	
	// Se explica en practicas.
	public SubconjuntosEdge greedyEdge() {
		Set<Integer> rest = Set2.difference(remaining, DatosSubconjuntos.getElementos(index));
		return rest.equals(remaining)? edge(0): edge(1);
	}
}
