package ejemplos.ejemplo2.manual;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.IntStream;

import _datos.DatosMulticonjunto;
import ejemplos.ejemplo1.MulticonjuntoVertex;
import us.lsi.common.List2;
import us.lsi.graphs.virtual.VirtualVertex;

public record SubconjuntosProblem(Integer index, Integer remaining) {

	public static SubconjuntosProblem of(Integer i, Integer rest) {
		return new SubconjuntosProblem(i, rest);
	}
	
	// TODO Consulte las clases GraphsPI5 y TestPI5 
	
	public static SubconjuntosProblem initial() {
		return of(0, DatosMulticonjunto.getSuma());
	}

	
	public List<Integer> actions() {
		List<Integer> alternativas = List2.empty();
		if(index < DatosMulticonjunto.getNumElementos()) {
			Integer value = DatosMulticonjunto.getElemento(index);
			Integer options = remaining / value;
			//alternativas = List2.rangeList(0, options + 1);
			//lo de arriba hace -->return IntStream.range(a,b).boxed().collect(Collectors.toList());
			//se podria dejar asi con el return alternativas
			if(index == DatosMulticonjunto.getNumElementos()-1) {
				if(remaining % value == 0) {
					alternativas.add(remaining / value);
				}else {
					alternativas.add(0);
				}
			}else {
				alternativas = List2.rangeList(0, options + 1);
			}
		}
		return alternativas;
	}
	
	
	public SubconjuntosProblem neighbor(Integer a) {
		return of(index + 1, remaining - a * DatosMulticonjunto.getElemento(index));
	}
	
	public Double heuristic() {
			
			Double res = 0.;
			if(remaining>0) {
				Integer max = IntStream.range(index, DatosMulticonjunto.getNumElementos())
						.map(i -> DatosMulticonjunto.getElemento(i))
						.filter(e -> e<=remaining).max().orElse(0);
				if(max>0) {
					Integer r = remaining/max;
					res += remaining%max==0? r: r+1;				
				} else 
					res += 100;
			} else
				res += 100;
			
			return res; 
	}


}
