package _soluciones;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.jgrapht.GraphPath;
import _datos.DatosEjercicio1;
import _datos.DatosEjercicio1.Variedad;
import ejercicios.ejercicio1.Ejercicio1Vertex;
import ejercicios.ejercicio1.Ejercicio1Edge;
import us.lsi.common.Map2;

public class SolucionEjercicio1 {
	public static SolucionEjercicio1 of(List<Integer> ls) {
		return new SolucionEjercicio1(ls);
	}

	public static SolucionEjercicio1 of(GraphPath<Ejercicio1Vertex, Ejercicio1Edge> path) {

		List<Integer> ls = path.getEdgeList().stream().map(e ->

		e.action()).toList();

		SolucionEjercicio1 res = of(ls);

		res.path = ls;
		return res;

	}

	private Integer beneficioTotal;

	private Map<Variedad, Integer> kilosVariedad;

	private List<Integer> path;

	private SolucionEjercicio1(List<Integer> ls) {
		beneficioTotal = 0;
		kilosVariedad = Map2.empty();
		for (int i = 0; i < ls.size(); i++) {
			if (ls.get(i) > 0) {
				Variedad v = DatosEjercicio1.getVariedad(i);
				Integer kg = ls.get(i);
				beneficioTotal += v.beneficio() * kg;
				kilosVariedad.put(v, kg);
			}
		}
	}

	@Override
	public String toString() {
		String intro = "Variedades de café seleccionadas:\n";
		String var = kilosVariedad.entrySet().stream().map(e -> e.getKey()+": "+e.getValue() + " kgs")
		.collect(Collectors.joining("\n"));
		String ben ="\nBeneficio: " + beneficioTotal;
		String res = intro + var + ben +"\n";
		return path==null? res: String.format("%s\nPath de la solucion: %s", res, path);		
	}
}


