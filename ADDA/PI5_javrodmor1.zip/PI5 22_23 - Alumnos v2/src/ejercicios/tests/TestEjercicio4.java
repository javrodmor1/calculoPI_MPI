package ejercicios.tests;

import java.util.List;

import _datos.DatosClientes;
import _soluciones.SolucionClientes;
import _utils.GraphsPI5;
import _utils.TestsPI5;
import ejercicios.ejercicio4.ClientesVertex;

public class TestEjercicio4 {
	public static void main(String[] args) {
		List.of(1,2).forEach(num_test -> {
			TestsPI5.iniTest("Ejercicio4DatosEntrada", num_test, DatosClientes::initDatos);

			TestsPI5.tests(
					ClientesVertex.initial(), 
					ClientesVertex.goal(), 
					GraphsPI5::clientesBuilder, 
					ClientesVertex::greedyEdge, 
					SolucionClientes::of); 
		});
	}
}
