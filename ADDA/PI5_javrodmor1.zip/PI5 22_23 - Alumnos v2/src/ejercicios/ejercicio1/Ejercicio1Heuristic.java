package ejercicios.ejercicio1;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.IntStream;

import _datos.DatosEjercicio1;

public class Ejercicio1Heuristic {
	public static Double heuristic(Ejercicio1Vertex v1, Predicate<Ejercicio1Vertex> goal, Ejercicio1Vertex v2) {

		return IntStream.range(v1.index(),
				DatosEjercicio1.getNumVariedadesM())
				.mapToDouble(variedad-> mejorOpcion(variedad,v1.remaining()))
				.sum();
	}

	private static Double mejorOpcion(Integer variedad, List<Integer> remaining) {
		Ejercicio1Vertex
		v = Ejercicio1Vertex.of(variedad, remaining);

		return IntStream.range(0, Ejercicio1Vertex.maximaCantidadPosibleVariedad(v) + 1)
				.filter(cant-> DatosEjercicio1.tipos.stream().allMatch(t -> cant *
						DatosEjercicio1.getPorcentajeTipoVariedad(v.index(), t.id()) <= v.remaining().get(t.id())))
				.boxed().mapToDouble(cant-> cant *
						DatosEjercicio1.getBeneficioVariedad(v.index()))
				.max().orElse(-1000.);

	}
}