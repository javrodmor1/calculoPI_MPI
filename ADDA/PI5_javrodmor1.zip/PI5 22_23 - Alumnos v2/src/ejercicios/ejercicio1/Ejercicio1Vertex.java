package ejercicios.ejercicio1;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import _datos.DatosEjercicio1;
import us.lsi.common.List2;
import us.lsi.graphs.virtual.VirtualVertex;

public record Ejercicio1Vertex(Integer index, List<Integer> remaining)
		implements VirtualVertex<Ejercicio1Vertex, Ejercicio1Edge, Integer> {

	public static Ejercicio1Vertex of(Integer i, List<Integer> r) {

		return new Ejercicio1Vertex(i, r);

	}

	public static Ejercicio1Vertex initial() {
		return of(0, DatosEjercicio1.tipos.stream().map(t ->

		t.kg()).toList());
	}

	public static Predicate<Ejercicio1Vertex> goal() {
		return v -> v.index() == DatosEjercicio1.getNumVariedadesM();

	}

	public static Predicate<Ejercicio1Vertex> goalHasSolution() {
		return v -> v.remaining().stream().allMatch(cantidad

		-> cantidad

				== 0);
	}

	public static Integer maximaCantidadPosibleVariedad(Ejercicio1Vertex v) {

		Integer sol = Integer.MAX_VALUE;
		Map<String, Double> componentes = DatosEjercicio1.getComponentesVariedad(v.index());

		for (Entry<String, Double> entrada : componentes.entrySet()) {
			Integer tipo = DatosEjercicio1.getTipo(entrada.getKey()).id();
			Double porcentaje = entrada.getValue();
			Integer restante = v.remaining().get(tipo);
			if (restante == 0) {
				sol = 0;
				break;
			} else {
				Double cantidad = restante / porcentaje;
				if (cantidad < sol) {
					sol = cantidad.intValue();
				}
			}
		}
		return sol;

	}

	@Override
	public List<Integer> actions() {
		List<Integer> alternativas = List2.empty();
		if (goal().test(this)) {
			return alternativas;
		}
		Integer maximo = maximaCantidadPosibleVariedad(this);
		for (Integer opcion = 0; opcion <= maximo; opcion++) {
			alternativas.add(opcion);
		}

		return alternativas;
	}

	@Override
	public Ejercicio1Vertex neighbor(Integer a) {
		Integer n_indice = this.index() + 1;
		List<Integer> n_remaining = List2.copy

		(this.remaining());

		if (a != 0) {
			Map<String, Double> porcentajes =

					DatosEjercicio1.getComponentesVariedad(this.index);
			Map<Integer, Double> cantidades =

					porcentajes.entrySet().stream()

							.collect(Collectors.toMap(

									e ->

									DatosEjercicio1.getTipo(e.getKey()).id(), e -> e.getValue() * a)

							);

			for (Entry<Integer, Double> entrada : cantidades.entrySet())

			{

				n_remaining.set(

						entrada.getKey(), n_remaining.get(entrada.getKey()) -

								entrada.getValue().intValue()

				);

			}
		}
		return of(n_indice, n_remaining);

	}

	@Override
	public Ejercicio1Edge edge(Integer a) {
		return Ejercicio1Edge.of

		(this, this.neighbor(a), a);

	}

	// COMPROBAR
	public Ejercicio1Edge greedyEdge() {
		Comparator<Integer> cmp = Comparator.comparing(cant -> cant *

				DatosEjercicio1.getBeneficioVariedad(index));

		Integer a = IntStream.range(0,

				maximaCantidadPosibleVariedad

				(this) + 1).filter(cant

		-> DatosEjercicio1.tipos.stream().allMatch(t -> cant *

				DatosEjercicio1.getPorcentajeTipoVariedad(index, t.id()) <=

				remaining.get(t.id())))

				.boxed().max(cmp).orElse(0);

		return edge(a);

	}
}