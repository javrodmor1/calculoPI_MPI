package ejercicios.ejercicio1;

import _datos.DatosEjercicio1;
import us.lsi.graphs.virtual.SimpleEdgeAction;

public record Ejercicio1Edge(Ejercicio1Vertex source, Ejercicio1Vertex target, Integer action, Double weight) 
	implements SimpleEdgeAction<Ejercicio1Vertex, Integer> {


// Peso: beneficio que reporta
	public static Ejercicio1Edge of(Ejercicio1Vertex s, Ejercicio1Vertex t, Integer a) {
		Double w = 0.;
		Integer indice = s.index();
		w = a * DatosEjercicio1.getBeneficioVariedad(indice).doubleValue();

		return new Ejercicio1Edge(s, t, a, w);

	}
}
