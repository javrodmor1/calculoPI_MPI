package ejercicios.ejercicio4;

import java.util.List;

import _datos.DatosClientes;
import _soluciones.SolucionClientes;
import us.lsi.common.List2;
import ejercicios.ejercicio4.*;

public class ClientesEstado {

	ClientesProblem actual;
	Double acumulado;
	List<Integer> acciones;
	List<ClientesProblem> anteriores;

	private ClientesEstado(ClientesProblem p, Double a, List<Integer> ls1, List<ClientesProblem> ls2) {
		actual = p;
		acumulado = a;
		acciones = ls1;
		anteriores = ls2;
	}

	public static ClientesEstado initial() {
		ClientesProblem p = ClientesProblem.initial();
		Double a = 0.;
		List<Integer> ls1 = List2.empty();
		List<ClientesProblem> ls2 = List2.empty();
		return new ClientesEstado(p, a, ls1, ls2);
	}

	public static ClientesEstado of(ClientesProblem prob, Double acum, List<Integer> lsa, List<ClientesProblem> lsp) {
		return new ClientesEstado(prob, acum, lsa, lsp);
	}

	public void forward(Integer a) {
		acumulado += a * DatosClientes.getBeneficio(actual.index());
		acciones.add(a);
		anteriores.add(actual);
		actual = actual.neighbor(a);
	}

	public void back() {
		int last = acciones.size() - 1;
		ClientesProblem prob_ant = anteriores.get(last);
		acumulado = acciones.get(last) * DatosClientes.getBeneficio(prob_ant.index());
		acciones.remove(last);
		anteriores.remove(last);
		actual = prob_ant;

	}

	public List<Integer> alternativas() {
		return actual.actions();
	}

	public Double cota(Integer a) {
		Double weight = DatosClientes.getBeneficio(a);
		return acumulado + weight + actual.neighbor(a).heuristic();
	}

	public Boolean esSolucion() {

		return actual.index() == 0 && actual.pendientes().isEmpty();
	}

	public Boolean esTerminal() {
		return actual.index() == 0 && actual.pendientes().isEmpty();
	}

	public SolucionClientes getSolucion() {
		return SolucionClientes.of_format(acciones);
	}

}
