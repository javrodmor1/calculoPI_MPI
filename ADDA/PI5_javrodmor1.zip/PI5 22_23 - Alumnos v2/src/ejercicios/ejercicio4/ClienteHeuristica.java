package ejercicios.ejercicio4;

import java.util.function.Predicate;

public class ClienteHeuristica {
	
	public static Double heuristic(ClientesVertex v1, Predicate<ClientesVertex> goal, ClientesVertex v2) {
		return 10000.;
	}

}
