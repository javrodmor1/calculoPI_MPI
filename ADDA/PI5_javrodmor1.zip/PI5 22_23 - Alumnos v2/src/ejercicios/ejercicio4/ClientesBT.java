package ejercicios.ejercicio4;

import java.util.Set;

import ejercicios.ejercicio4.*;
import _soluciones.SolucionClientes;
import us.lsi.common.Set2;

public class ClientesBT {

	private static Double mejorValor;
	private static ClientesEstado estado;
	private static Set<SolucionClientes> soluciones;

	public static void search() {
		soluciones = Set2.newTreeSet();
		mejorValor = Double.MIN_VALUE;
		estado = ClientesEstado.initial();
		bt_search();
	}

	private static void bt_search() {
		if (estado.esSolucion()) {
			Double valorObtenido = estado.acumulado;
			if (valorObtenido > mejorValor) {
				mejorValor = valorObtenido;
				soluciones.add(estado.getSolucion());
			}
		} else if (!estado.esTerminal()) {

			for (Integer a : estado.alternativas()) {
				if (estado.cota(a) >= mejorValor) {

					estado.forward(a);
					bt_search();
					estado.back();
				}
			}
		}
	}

	public static Set<SolucionClientes> getSoluciones() {
		return soluciones;
	}

}
