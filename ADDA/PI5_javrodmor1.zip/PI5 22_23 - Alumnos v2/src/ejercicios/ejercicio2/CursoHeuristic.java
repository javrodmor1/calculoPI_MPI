package ejercicios.ejercicio2;

import java.util.function.Predicate;
import java.util.stream.IntStream;

import _datos.DatosCursos;
import us.lsi.common.List2;

public class CursoHeuristic {
	public static Double heuristic(CursoVertex a, Predicate<CursoVertex> goal, CursoVertex b) {
		return a.remaining().isEmpty() ? 0.
				: IntStream.range(a.index(), DatosCursos.getNumCursos())
						.filter(v -> !List2.intersection(a.remaining(), DatosCursos.getTematicasCurso(v)).isEmpty())
						.mapToDouble(v -> DatosCursos.getPrecioCurso(v)).min().orElse(100.);
	}
}
