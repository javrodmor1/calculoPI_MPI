package _datos;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import us.lsi.common.Files2;

public class DatosCursos {

	public static List<Curso> cursos;
	public static Set<Integer> tematicas;
	public static Integer maxCentros;

	public record Curso(Integer id, Set<Integer> tematicas, Double precio, Integer centro) {

		public static int cont;
		public static Curso of(Set<Integer> temsCurso, Double prec, Integer centr) {
			return new Curso(cont++, temsCurso, prec, centr);
		}
	}

	public static void iniDatos(String fichero) {
		tematicas = new HashSet<>();
		cursos = new ArrayList<>();
		maxCentros = 0;

		Files2.linesFromFile(fichero).forEach(l -> {

			if (l.startsWith("M")) {
				String[] c = l.split("=");
				maxCentros = Integer.valueOf(c[1].trim());
			} else {
				String[] c = l.split(":");
				Set<Integer> temsCurso = new HashSet<>();
				String[] tems = c[0].replace("{", "").replace("}", "").split(",");
				for (String tem : tems) {
					Integer tematica = Integer.valueOf(tem);
					temsCurso.add(tematica);
					tematicas.add(tematica);
				}
				Double coste = Double.valueOf(c[1].trim());
				Integer centro = Integer.valueOf(c[2].trim());
				Curso curs = Curso.of(temsCurso, coste, centro);
				cursos.add(curs);
			}
		});

	}

	public static Integer getMaxCentros() {
		return maxCentros;
	}

	public static Integer getCentroCurso(Integer i) {
		return getCurso(i).centro();
	}

	public List<Curso> cursosImpartenTematica(Integer i) {
		List<Curso> res = new ArrayList<>();
		for (Curso c : cursos) {
			if (c.tematicas().contains(i)) {
				res.add(c);
			}
		}
		return res;
	}

	public static List<Curso> getCursos() {
		return cursos;
	}

	public static Integer getNumCursos() {

		return getCursos().size();
	}

	public static Double getPrecioCurso(Integer i) {

		return cursos.get(i).precio();
	}

	public static Curso getCurso(Integer i) {
		return cursos.get(i);
	}

	public static Set<Integer> getTematicas() {
		return tematicas;
	}

	public static Integer getNumTematicas() {
		return getTematicas().size();
	}

	public static Set<Integer> getTematicasCurso(Integer i) {

		return cursos.get(i).tematicas();
	}

	public static void toConsole(){
		 System.out.println( "Maximo numero de colegios a elegir: "+maxCentros+ "\nCursos disponibles: "+cursos);
		 }

	public static void main(String[] args){
		 System.out.println("DATOS DE ENTRADA 1:");
		 iniDatos("ficheros/Ejercicio2DatosEntrada1.txt");
		 System.out.println("___________________________");
		 System.out.println("DATOS DE ENTRADA 2:");
		 iniDatos("ficheros/Ejercicio2DatosEntrada2.txt");
		 System.out.println("___________________________");
		 System.out.println("DATOS DE ENTRADA 3:");
		 iniDatos("ficheros/Ejercicio2DatosEntrada3.txt");
		 }
}