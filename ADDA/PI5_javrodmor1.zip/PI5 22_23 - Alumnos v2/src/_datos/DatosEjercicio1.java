package _datos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import us.lsi.common.Files2;
import us.lsi.common.List2;

public class DatosEjercicio1 {
	public static record Tipo(Integer id, String nombre, Integer kg) {

		public static int contt;

		public static Tipo create(String linea) {
			String[] v = linea.split(":");
			String nombre = v[0].trim();

			String[] v2 = v[1].split("=");
			Integer kg = Integer.parseInt
			(v2[1].trim().replace(";",""));

			return new Tipo(contt++, nombre, kg);
		}

		@Override
		public String toString() {
			return String.format

			("%s: %d kgs", nombre, kg);

		}
	}

	public static record Variedad(Integer id, String nombre, Integer beneficio, Map<String, Double> comp) {

		public static int contv;

		public static Variedad create(String linea) {
			String[] v1 = linea.split(";");

			String[] v2 = v1[0].split("->"); // nombre : beneficio

			String nombre = v2[0].trim();
			String[] v3 = v2[1].split("="); // beneficio = num

			Integer beneficio = Integer.parseInt(v3[1].trim());
			String[] v4 = v1[1].split("="); // comp = tuplas
			String[] v5 = v4[1].split(","); // tuplas

			Map<String, Double> comp = new HashMap<>();
			for (String tupla : v5) {
				tupla = tupla.trim().replace("(", "").replace(")", "");
				String[] v = tupla.split(":");
				String nombreTipo = v[0].trim();
				Double porcentaje = Double.parseDouble(v[1].trim().replace(";", ""));
				comp.put(nombreTipo, porcentaje);
			}
			return new Variedad(contv++, nombre, beneficio, comp);
		}

		public String toString() {
			return String.format("%s", nombre);
		}
	}

	public static List<Tipo> tipos;
	public static List<Variedad> variedades;

	public static void iniDatos(String fichero) {
		Tipo.contt = 0;
		Variedad.contv = 0;
		tipos = List2.empty();
		variedades = List2.empty();
		List<String> lineas = Files2.linesFromFile(fichero);
		Integer i2 = lineas.indexOf("// VARIEDADES");
		for (Integer i = 0; i < lineas.size(); i++) {
			if (i != 0 && i < i2) {
				Tipo t = Tipo.create(lineas.get(i));
				tipos.add(t);
			} else if (i > i2) {
				Variedad v = Variedad.create(lineas.get(i));
				variedades.add(v);
			}
		}
	}

	public static Variedad getVariedad(Integer i) {

		return variedades.get(i);

	}

	public static Tipo getTipo(Integer j) {

		return tipos.get(j);

	}

	public static Tipo getTipo(String nombre) {
		return tipos.stream().filter(t ->

		t.nombre.equals(nombre)).findFirst().get();
	}

	public static Integer getKgTipo(Integer j) {

		return tipos.get(j).kg();

	}

	public static Integer getBeneficioVariedad(Integer i) {
		return variedades.get(i).beneficio();
	}

	public static Map<String, Double> getComponentesVariedad(Integer i) {
		return variedades.get(i).comp();
	}

	public static Double getPorcentajeTipoVariedad(Integer i, Integer j) {
		Map<String, Double> comp = getComponentesVariedad(i);
		String nombreT = tipos.get(j).nombre();
		return variedadContieneTipo(i,j) == 1 ? comp.get(nombreT) : 0.0;
	}
	
	public static Integer getNumTiposN() {
		return tipos.size();
	}

	public static Integer getNumVariedadesM() {
		return variedades.size();
	}

	public static Integer variedadContieneTipo(Integer i, Integer j) {

		Map<String, Double> comp = getComponentesVariedad(i);
		String nombreT = tipos.get(j).nombre();
		return comp.keySet().contains(nombreT) ? 1 : 0;
	}

	// Test lectura de ficheros
	public static void main(String[] args) {
		iniDatos("ficheros/Ejercicio1DatosEntrada1.txt");
		System.out.println(tipos);
		System.out.println(variedades);
	}
}