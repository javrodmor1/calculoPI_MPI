package _utils;

import java.util.function.Predicate;

import ejemplos.ejemplo1.MulticonjuntoEdge;
import ejemplos.ejemplo1.MulticonjuntoHeuristic;
import ejemplos.ejemplo1.MulticonjuntoVertex;
import ejemplos.ejemplo2.SubconjuntosEdge;
import ejemplos.ejemplo2.SubconjuntosHeuristic;
import ejemplos.ejemplo2.SubconjuntosVertex;
import ejemplos.ejemplo3.AlumnosEdge;
import ejemplos.ejemplo3.AlumnosVertex;
import ejercicios.ejercicio1.Ejercicio1Edge;
import ejercicios.ejercicio1.Ejercicio1Heuristic;
import ejercicios.ejercicio1.Ejercicio1Vertex;
import ejercicios.ejercicio2.CursoEdge;
import ejercicios.ejercicio2.CursoHeuristic;
import ejercicios.ejercicio2.CursoVertex;
import ejercicios.ejercicio4.ClienteHeuristica;
import ejercicios.ejercicio4.ClientesEdge;
import ejercicios.ejercicio4.ClientesVertex;
import us.lsi.graphs.virtual.EGraph;
import us.lsi.graphs.virtual.EGraphBuilder;
import us.lsi.graphs.virtual.EGraph.Type;
import us.lsi.path.EGraphPath.PathType;

// Clase Factoria para crear los constructores de los grafos de los ejemplos y ejercicios
public class GraphsPI5 {

	// Ejemplo1: Builder
	public static EGraphBuilder<MulticonjuntoVertex, MulticonjuntoEdge> multisetBuilder(MulticonjuntoVertex v_inicial,
			Predicate<MulticonjuntoVertex> es_terminal) {
		return EGraph.virtual(v_inicial, es_terminal, PathType.Sum, Type.Min)
				// TODO Defina en el tipo vertice un m. static / Predicate para los vertices
				// solucion
				.goalHasSolution(MulticonjuntoVertex.goalHasSolution()).heuristic(MulticonjuntoHeuristic::heuristic);
	}

	// Ejemplo2: Builder
	public static EGraphBuilder<SubconjuntosVertex, SubconjuntosEdge> subsetBuilder(SubconjuntosVertex v_inicial,
			Predicate<SubconjuntosVertex> es_terminal) {
		return EGraph.virtual(v_inicial, es_terminal, PathType.Sum, Type.Min)
				// TODO Defina en el tipo vertice un m. static / Predicate para los vertices
				// solucion
				.goalHasSolution(SubconjuntosVertex.goalHasSolution()).heuristic(SubconjuntosHeuristic::heuristic);
	}

	// Ejemplo3: Builder
	public static EGraphBuilder<AlumnosVertex, AlumnosEdge> alumnosBuilder(AlumnosVertex v_inicial,
			Predicate<AlumnosVertex> es_terminal) {
		// TODO Implementarlo de forma similar a los de los ejemplos 1 y 2
		return null;
	}

	// Ejercicio1: Builder
	public static EGraphBuilder<Ejercicio1Vertex, Ejercicio1Edge> ejercicio1Builder(Ejercicio1Vertex v_inicial,
			Predicate<Ejercicio1Vertex> es_terminal) {
		return EGraph.virtual(v_inicial, es_terminal, PathType.Sum,
				Type.Max).goalHasSolution(Ejercicio1Vertex.goalHasSolution())
				.heuristic(Ejercicio1Heuristic::heuristic);

	}
	
	public static EGraphBuilder<Ejercicio1Vertex,Ejercicio1Edge>cafesBuilder(Ejercicio1Vertex v_inicial,Predicate<Ejercicio1Vertex>es_terminal){
        return EGraph.virtual(v_inicial,es_terminal,PathType.Sum,Type.Max).goalHasSolution
                (Ejercicio1Vertex.goalHasSolution()).heuristic(Ejercicio1Heuristic::heuristic);
    }
    
    public static EGraphBuilder<CursoVertex, CursoEdge> cursosBuilder(CursoVertex v, Predicate<CursoVertex> est){
    	return EGraph.virtual(v, est, PathType.Sum, Type.Min).goalHasSolution(CursoVertex.goalHasSolution()).heuristic(CursoHeuristic::heuristic);
    }
    
    public static EGraphBuilder<ClientesVertex, ClientesEdge> clientesBuilder(ClientesVertex v, Predicate<ClientesVertex> est){
    	return EGraph.virtual(v, est, PathType.Sum, Type.Min).goalHasSolution(ClientesVertex.goalHasSolution()).heuristic(ClienteHeuristica::heuristic);
    }

}
