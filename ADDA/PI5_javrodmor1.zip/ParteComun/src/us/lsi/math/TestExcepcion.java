package us.lsi.math;



public class TestExcepcion {
		public static void main(String[] args) {
			Racional r = null ;
			r = Racional.create(1, 0);
			System.out.println(r);
			System.out.println (" Final del programa");
		}
}
